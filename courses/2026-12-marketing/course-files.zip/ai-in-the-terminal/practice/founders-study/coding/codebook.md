# Codebook

- **TRIGGER**: what made the founder reconsider
- **ADVICE**: who they asked
- **IDENTITY**: talk about who they are as a founder
- **REGRET**: what they would change
