d <- read.csv("data/survey_clean.csv")
summary(lm(wtp_nok ~ pivoted + firm_age + team_size, data = d))
