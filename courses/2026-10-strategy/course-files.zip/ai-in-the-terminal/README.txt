AI in the terminal: Claude Code and Codex. BI, Strategy and Entrepreneurship,
22 and 23 October 2026.

Open handout.html in your browser: every prompt from the day, with a copy button.
The practice folders are in practice/, ready to use: copy one into your own
practice folder. (The handout also has a prompt that makes the agent fetch each
one.)

Questions: jonas.moss@bi.no
