AI in the terminal: Claude Code and Codex. BI, Finance, 16 October 2026.

Open handout.html in your browser: every prompt from the day, with a copy button.
The practice folders are in practice/. The handout tells the agent how to fetch
them, but you can also unzip them yourself.

Questions: jonas.moss@bi.no
